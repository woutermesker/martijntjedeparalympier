package com.backbase.plugin.container.flowonrefreshcontainer;


import com.aquima.interactions.composer.IButton;
import com.aquima.interactions.composer.IContainer;
import com.aquima.interactions.composer.IElement;
import com.aquima.interactions.composer.IField;
import com.aquima.interactions.composer.model.Composer;
import com.aquima.interactions.composer.model.Container;
import com.aquima.interactions.composer.model.definition.ContainerDefinition;
import com.aquima.interactions.flow.ExitEvent;
import com.aquima.interactions.flow.FlowException;
import com.aquima.interactions.flow.IActionNodeDetails;
import com.aquima.interactions.flow.IFlowDetails;
import com.aquima.interactions.flow.IFlowHandler;
import com.aquima.interactions.flow.IFlowState;
import com.aquima.interactions.flow.exception.FlowAccessException;
import com.aquima.interactions.foundation.IPrimitiveValue;
import com.aquima.interactions.foundation.exception.AppException;
import com.aquima.interactions.foundation.exception.InvalidArgumentException;
import com.aquima.interactions.foundation.logging.LogFactory;
import com.aquima.interactions.foundation.logging.Logger;
import com.aquima.interactions.foundation.text.StringUtil;
import com.aquima.interactions.portal.ICallbackFunction;
import com.aquima.interactions.portal.IContainerContext;
import com.aquima.interactions.portal.IContainerEventContext;
import com.aquima.interactions.portal.IContainerExpander;
import com.aquima.interactions.portal.IServiceCall;
import com.aquima.interactions.portal.IServiceResult;
import com.aquima.interactions.portal.InvocationType;
import com.aquima.interactions.portal.ServiceException;
import com.aquima.interactions.portal.model.def.ServiceCallEvent;
import com.aquima.interactions.portal.model.flow.ServiceNode;
import com.aquima.interactions.rule.InferenceContext;
import com.aquima.web.config.annotation.AquimaExpander;


/**
 * FlowOnRefresh Container Implementation
 *
 *
 */

@AquimaExpander("BB_FlowOnRefresh")
public class FlowOnRefreshContainer implements IContainerExpander {
	private static final Logger LOG = LogFactory.getLogger(Composer.class);

	private static class FlowStarter implements ICallbackFunction {
		private final String flowName;

		private boolean triggered = false;
		private boolean validateBeforeFlowing = false;

		public FlowStarter(String flowName, boolean validateBeforeFlowing) {
			this.flowName = flowName;
			this.validateBeforeFlowing = validateBeforeFlowing;
		}

		public InvocationType getInvocationType() {
			if (validateBeforeFlowing) {
				return InvocationType.ON_EVENT;
			}
			return InvocationType.ON_EVENT.beforeValidation();

		}

		@Override
		public void handle(IElement element, IContainerEventContext context) throws Exception {
			if (!triggered) {
				triggered = true;
				LOG.debug("Starting flow on refresh: " + flowName);
				IFlowState flowState = context.getFlowEngine().startFlow(flowName, new FlowHandler(context));
				if (!flowState.isComplete()) {
					LOG.warning("[startFlow] Refresh flow did not complete, it should not container pages: '" + flowName + "'");
					throw new AppException("Refresh flow '" + flowName + "' should not contain pages");
				}
			}
		}
	}

	private static class FlowHandler implements IFlowHandler {
		private final IContainerEventContext context;



		public FlowHandler(IContainerEventContext context) {
			this.context = context;
			// repeatBehaviour = new InstanceRepeatFlowBehaviour(context);
		}



		@Override
		public InferenceContext getProfile() {
			// return repeatBehaviour.getProfile();
			return context.getProfile();
		}

		@Override
		public void onConditionException(Exception error) {}

		@Override
		public void onFlowAborted(IFlowDetails flow) {
			// repeatBehaviour.onFlowAborted(flow);
		}



		@Override
		public void onFlowAccessException(FlowAccessException exception) throws FlowException {}



		@Override
		public void onFlowCompleted(IFlowDetails flow) {
			// repeatBehaviour.onFlowCompleted(flow);
		}

		@Override
		public void onFlowContinue(String flowName) {}



		@Override
		public void onFlowStart(IFlowDetails flow) {
			// repeatBehaviour.onFlowStart(flow);
		}

		@Override
		public void onFlowWillStart(IFlowDetails flow) throws FlowAccessException {}



		@Override
		public void onRepeatContextEnd(IPrimitiveValue repeatValue) {
			// repeatBehaviour.onRepeatContextEnd(repeatValue);
		}



		@Override
		public void onRepeatContextStart(IPrimitiveValue repeatValue) {
			// repeatBehaviour.onRepeatContextStart(repeatValue);
		}



		@Override
		public ExitEvent process(IActionNodeDetails action) throws Exception {
			ServiceNode node = (ServiceNode) action;
			IServiceCall serviceCall = null;
			IServiceResult result = null;
			try {
				serviceCall = context.getServiceManager().getServiceCall(node.getActionId());
				// result = serviceCall.handle(repeatBehaviour.createInternalContext());
				result = serviceCall.handle(context);
			} catch (ServiceException e) {
				context.addErrorText(null, e.getErrorMessage());
			}
			if (result == null || result.getEvent() == null) {
				return ExitEvent.DEFAULT;
			} else {
				ServiceCallEvent[] exitEvents = serviceCall.getExitEvents();
				for (ServiceCallEvent exitEvent : exitEvents) {
					if (exitEvent.getTypeName().equalsIgnoreCase(result.getEvent())) {
						return ExitEvent.forLabel(exitEvent.getLabel());
					}
				}
				return ExitEvent.DEFAULT;
			}
		}
	}



	@Override
	public Container expand(Container container, ContainerDefinition definition, IContainerContext context)
			throws Exception {
		// Expand default children
		container.addElements(context.getElementComposer().expandChildren(definition));



		// Add refresh callback
		String flowName = context.getParameter("flow");
		boolean validateBeforeFlowing =
				context.getParameters().getTypedParameter("ValidateBeforeFlowing").getValue().booleanValue();

		if (StringUtil.isEmpty(flowName)) {
			throw new InvalidArgumentException("invalid parameter flow");
		}


		FlowStarter starter = new FlowStarter(flowName, validateBeforeFlowing);
		addRefreshCallback(container, context, starter);
		return container;
	}



	private void addRefreshCallback(IContainer container, IContainerContext context, FlowStarter starter) {
		IElement[] children = container.getElements();
		for (IElement child : children) {
			if (child instanceof IField) {
				IField field = (IField) child;
				if (field.isRefreshField()) {
					context.registerCallback(field, starter, starter.getInvocationType());
				}

			} else if (child instanceof IButton) {
				IButton button = (IButton) child;
				if (button.isRefresh()) {
					context.registerCallback(button, starter, starter.getInvocationType());
				}

			} else if (child instanceof IContainer) {
				addRefreshCallback((IContainer) child, context, starter);
			}
		}


	}

}
